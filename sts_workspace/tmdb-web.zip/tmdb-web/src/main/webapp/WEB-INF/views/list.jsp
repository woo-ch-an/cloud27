<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="/css/tmdb-web.css" type="text/css" />
<title>Movie List</title>
</head>
<body>
	<div class="wrapper">
		<h1>Movie List</h1>

		<table class="grid">

			<thead>
				<tr>
					<th>Movie Name</th>
					<th>Movie Rate</th>
					<th>Introduce</th>
					<th>Running Time</th>
				</tr>
			</thead>
			<tbody>
				<c:choose>
					<c:when test="${not empty movieResult}">
						<c:forEach items="${movieResult }" var="movie">
							<tr>
								<td>${movie.title }</td>
								<td>${movie.movieRating }</td>
								<td>${movie.introduce}</td>
								<td>${movie.runningTime }m</td>
							</tr>
						</c:forEach>
					</c:when>
					<c:otherwise>
						<tr>
							<td colspan="4">No Data</td>
						</tr>
					</c:otherwise>
				</c:choose>

			</tbody>

		</table>
		<div class="align-right">
			<a class="btnlike" href="/write"> Add Moive</a>
		</div>
	</div>
</body>
</html>