<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h1><a href="/list">/list ListPage </a></h1>
<h3>영화 리스트 페이지</h3>

<h1> <a href="/write">/write Write Page</a></h1>
<h3> 영화 추가 페이지</h3>
</body>
</html>