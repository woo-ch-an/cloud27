package org.themoviedb.www.movie.vo.request;

public class WriteVO {

}
