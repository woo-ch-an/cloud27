package org.themoviedb.www.movie.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.themoviedb.www.movie.dao.MovieDao;
import org.themoviedb.www.movie.vo.MovieVO;
import org.themoviedb.www.movie.vo.response.SearchResultVO;

@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	private MovieDao movieDao;
	@Override
	public SearchResultVO findAllMovies() { 

		SearchResultVO result = new SearchResultVO(); 
		
		//영화 개su조회
		int count = this.movieDao.selectMovieCount(); 
		result.setCount(count);
		if(count ==0) {
			return result;
		}
		// 영화 목록조회 
		
		List<MovieVO> list = this.movieDao.selectMovieList(); 
		
		result.setResult(list);

		return result;
	}
	@Override
	public boolean creatNewMovie(MovieVO movieVO)  {
		
		int insertCount = this.movieDao.insertNewMovie(movieVO);
		
		
		return insertCount ==1;
	}

	
}
